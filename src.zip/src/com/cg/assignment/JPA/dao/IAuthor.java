package com.cg.assignment.JPA.dao;

public interface IAuthor {

}
