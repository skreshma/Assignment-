package com.cg.assignment.JPA.dao;

public class AuthorDAO {

}
