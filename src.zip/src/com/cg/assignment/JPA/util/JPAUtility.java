package com.cg.assignment.JPA.util;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtility {
	static EntityManagerFactory factory = null;
	static {
		factory = Persistence.createEntityManagerFactory("author_bu");
	}
	public static EntityManagerFactory getFactory() {
		return factory;
	}
	
}
