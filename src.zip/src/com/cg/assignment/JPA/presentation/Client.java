package com.cg.assignment.JPA.presentation;

public class Client {

}
