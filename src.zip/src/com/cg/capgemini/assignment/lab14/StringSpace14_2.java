package com.cg.capgemini.assignment.lab14;

public class StringSpace14_2 {
	public static void main(String[] args) {
		TestString ts = (s)->{
			String st = "";
			for(int i = 0;i < s.length()-1;i++) 
				st += s.charAt(i)+" ";
			st += s.charAt(s.length()-1);
			return st;
		};
		System.out.println(ts.stringSpace("Cap"));
	}
}
interface TestString {
	String stringSpace(String str);
}