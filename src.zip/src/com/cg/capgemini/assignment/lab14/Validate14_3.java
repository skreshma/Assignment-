package com.cg.capgemini.assignment.lab14;

public class Validate14_3 {
	public static void main(String[] args) {
		Validation v = (u,p)-> {
			if(u.equals("adyan") && p.equals("Adyan123"))
				return true;
			else
				return false;
		};
		System.out.println(v.authenticate("Adyan", "Adyan123"));
	}
}
interface Validation {
	boolean authenticate(String uname, String pwd);
}
