package com.cg.capgemini.assignment.lab14;

import java.util.function.Function;

public class Fact14_5 {
	public static void main(String[] args) {
		Function<Integer,Integer> f = Factorial14_5 :: fact;
		System.out.println(f.apply(5));
	}
}
