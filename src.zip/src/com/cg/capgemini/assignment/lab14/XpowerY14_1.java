package com.cg.capgemini.assignment.lab14;

public class XpowerY14_1 {
	public static void main(String[] args) {
		Test t = (a, b) -> {
			return Math.pow(a, b);
		};
		System.out.println(t.power(3, 4));
	}

}

interface Test {
	double power(double x, double y);
}