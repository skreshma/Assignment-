package com.cg.capgemini.assignment.lab14;

public class SetterGetter14_4 {
	public static void main(String[] args) {
		SetGet14_4 s = new SetGet14_4("reshma","reshu");
		Test t = s :: get;
	}
}
class Test {
	public void get() {
		SetGet14_4 s = new SetGet14_4("reshma","reshu");
		
	}
}