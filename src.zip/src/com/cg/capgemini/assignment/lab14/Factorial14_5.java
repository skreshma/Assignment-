package com.cg.capgemini.assignment.lab14;

public class Factorial14_5 {
	public static int fact(int num) {
		int res = 1;;
		while(num != 0) {
			res = res*num;
			num = num-1;
		}
		return res;
	}
}
