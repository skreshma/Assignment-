package com.cg.eis.exception;

public class EmployeeException6_3 extends Exception {
	
	public String getMessage() {
		return "Salary is too low";
	}
}
