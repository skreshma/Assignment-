package com.capgemini.assignment.lab9;

public class Employee9_2_2 {
	int empId;
	String empName;
	double empSalary;
	
	public Employee9_2_2() {
		super();
	}
	public Employee9_2_2(int empId, String empName, double empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) throws Exceptionclass9_2_2 {
		if(empSalary > 5000)
			this.empSalary = empSalary;
		else
			throw new Exceptionclass9_2_2();
	}
	
}
