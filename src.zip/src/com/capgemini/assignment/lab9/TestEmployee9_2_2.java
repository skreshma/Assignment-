package com.capgemini.assignment.lab9;

import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;


public class TestEmployee9_2_2 {
	static Employee9_2_2 e;
	@BeforeClass
	public static void preInit() throws Exceptionclass9_2_2 {
		e = new Employee9_2_2();
		e.setEmpId(1);
		e.setEmpName("Name");
		e.setEmpSalary(2000.0);
	}
	@Test(expected = Exceptionclass9_2_2.class)
	public void getSalary() {
		double ExpectedResult = 56000.0;
		double actualResult = e.getEmpSalary();
		if(ExpectedResult == actualResult)
			System.out.println("True");
		else
			System.out.println("False");
		}
}
