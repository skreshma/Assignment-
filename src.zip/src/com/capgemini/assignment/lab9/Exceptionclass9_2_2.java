package com.capgemini.assignment.lab9;

public class Exceptionclass9_2_2 extends Exception {
	
	public String getMessage() {
		return "Salary is too low";
	}
}
 