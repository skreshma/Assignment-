package com.capgemini.assignment.lab9;

import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;


public class DateTestcase9_2 {
	static Date9_2 d;
	@BeforeClass
	public static void preInit() {
		
		d = new Date9_2(28,1,2020);
	}
	@Test
	public void getDay() {
		int expectedResult = 31;
		int actualResult = d.getDay();
		//System.out.println(actualResult);
		//Assert.assertSame("Valid", expectedResult, actualResult);
		Assert.assertFalse("Invalid", actualResult > expectedResult);
	}
	@Test
	public void getMonth() {
		int expectedResult = 12;
		int actualResult = d.getMonth();
		/*System.out.println(actualResult);
		if(actualResult <= expectedResult)
			System.out.println("CurrentMonth is : "+actualResult);*/
		Assert.assertFalse("Invalid", actualResult > expectedResult);
	}
	@Test
	public void getYear() {
		int expectedResult = 1955;
		int actualResult = d.getYear();
		/*System.out.println(actualResult);
		if(actualResult >= expectedResult)
			System.out.println("CurrentYear is : "+actualResult);*/
		Assert.assertFalse("Invalid", actualResult < expectedResult);
	}
}

