package com.capgemini.assignment.lab9;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PersonTestcase9_1 {
	@Test
	public void testGetFullName() {
		System.out.println("from PersonTestcase");
		Person9_1 per = new Person9_1("Robert", "King");
		assertEquals("Robert King", per.getFullName());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testNullsInName() {
		System.out.println("from PersonTestcase testing exceptions");
		Person9_1 per1 = new Person9_1(null, null);
		per1.getFullName();
	}

}
