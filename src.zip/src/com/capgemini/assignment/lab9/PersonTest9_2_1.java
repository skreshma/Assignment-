package com.capgemini.assignment.lab9;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class PersonTest9_2_1 {
	static Person9_2_1 p;
	@BeforeClass
	public static void preInt() {
		p = new Person9_2_1();
	}
	@Test
	public void getFirstName() {
		String actualResult = p.getFirstName();
		Assert.assertNotNull("FirstName shouldn't be null", actualResult);
	}
	@Test
	public void getLastName() {
		String actualResult = p.getLastName();
		Assert.assertNotNull("LastName shouldn't be null", actualResult);
	}
	@Test
	public void getGender() {
		char actualResult = p.getGender();
		Assert.assertTrue("Enter valid Gender", (actualResult == 'F' || actualResult == 'M'));
	}
	@Test
	public void getDetails() {
		String actualResult = p.toString();
		System.out.println(actualResult);
		Assert.assertNotNull("No Details", actualResult);
		
	}
}
