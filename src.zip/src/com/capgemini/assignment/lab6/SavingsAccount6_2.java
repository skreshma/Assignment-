package com.capgemini.assignment.lab6;

public class SavingsAccount6_2 extends Account6_2 {
	public SavingsAccount6_2(double balance, Person6_2 p1) {
		super(balance, p1);
	}
	final double minBal = 500;
	public boolean withdraw(double amt) {
		System.out.println("Savings");
		if (this.balance - amt < 500) {
			System.out.println("Can't withdraw");
			return false;
		} else {
			this.balance = this.balance-amt;
			return true;
		}
	}
}
