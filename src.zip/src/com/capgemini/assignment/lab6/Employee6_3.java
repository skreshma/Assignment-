package com.capgemini.assignment.lab6;

import com.cg.eis.exception.EmployeeException6_3;

public class Employee6_3 {
	int empId;
	String empName;
	double empSalary;
	public Employee6_3(int empId, String empName, double empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) throws EmployeeException6_3 {
		if(empSalary >= 5000)
			this.empSalary = empSalary;
		else
			throw new EmployeeException6_3();
	}
	
}
