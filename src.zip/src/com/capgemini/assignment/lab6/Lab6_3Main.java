package com.capgemini.assignment.lab6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.cg.eis.exception.EmployeeException6_3;

public class Lab6_3Main {
	public static void main(String[] args) throws IOException, EmployeeException6_3 {
		
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter employee Id : ");
	int empId = sc.nextInt();
	System.out.println("Enter employee Name : ");
	String empName = sc.next();
	System.out.println("Enter employee Salary : ");
	double empSal = sc.nextDouble();
	Employee6_3 emp = new Employee6_3(empId,empName,empSal);
	//System.out.println(emp);
	emp.setEmpSalary(empSal);
	}
}
