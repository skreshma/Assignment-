package com.capgemini.assignment.lab6;

public class Lab6_1 {
	String firstName;
	String lastName;
	char gender;
	public Lab6_1() {
		super();
	}
	public Lab6_1(String firstName, String lastName, char gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) throws Exception6_1 {
		try {
			if (firstName != "")
				this.firstName = firstName;
			else
				throw new Exception6_1("FirstName shouldn't be null");
		} catch(Exception6_1 exe) {
			System.out.println(exe);
		}
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) throws Exception6_1 {
		try {
			if (lastName != "")
				this.lastName = lastName;
			else
				throw new Exception6_1("LastName shouldn't be null");
		} catch(Exception6_1 exe) {
			System.out.println(exe);
		}
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "Lab6_1 [firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender + "]";
	}
	
}
