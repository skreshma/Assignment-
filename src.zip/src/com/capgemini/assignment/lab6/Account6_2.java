package com.capgemini.assignment.lab6;

public class Account6_2 extends Person6_2 {
	long accNum;
	double balance;
	Person6_2 accHolder;
	static long count = 1;
	public Account6_2( double balance, Person6_2 accHolder) {
		super();
		this.accNum = count;
		count++;
		this.balance = balance;
		this.name = accHolder.getName();
		this.age = accHolder.getAge();
	}
	public Account6_2() {
		super();
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public void deposit(double amt) {
		System.out.println(this.name + " Balance is : " + this.balance);
		this.balance = balance + amt;

	}

	public boolean withdraw(double amt) {
		if (this.balance - amt < 500) {
			System.out.println("Can't withdraw");
			return false;
		} else {
			this.balance = this.balance-amt;
			return true;
		}
	}
	@Override
	public String toString() {
		return "Account6_2 [accNum=" + accNum + ", balance=" + balance + ", name=" + name + ", age=" + age + "]";
	}
	
}
