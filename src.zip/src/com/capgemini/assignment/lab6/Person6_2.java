package com.capgemini.assignment.lab6;

public class Person6_2 {
	String name;
	float age;
	public Person6_2(String name, float age) {
		super();
		this.name = name;
		this.age = age;
	}
	public Person6_2() {
		super();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) throws Exception6_2 {
		try {
			if(age > 15) 
				this.age = age;
			else
				throw new Exception6_2("Age must be greater than 15");
		} catch(Exception6_2 exe) {
			System.out.println(exe);
		}
	}
	
}
