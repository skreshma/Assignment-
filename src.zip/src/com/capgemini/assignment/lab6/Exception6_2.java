package com.capgemini.assignment.lab6;

public class Exception6_2 extends Exception {
	String str;

	public Exception6_2(String str) {
		super();
		this.str = str;
	}

	@Override
	public String toString() {
		return "Exception occured : "+str;
	}
}
