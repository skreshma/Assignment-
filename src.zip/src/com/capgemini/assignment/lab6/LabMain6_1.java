package com.capgemini.assignment.lab6;

public class LabMain6_1 {
	public static void main(String[] args) throws Exception {
		Lab6_1 l = new Lab6_1();
		l.setFirstName("");
		l.setLastName("");
		l.setGender('F');
		System.out.println(l);
	}
}
