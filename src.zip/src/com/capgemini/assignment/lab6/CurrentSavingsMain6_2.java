package com.capgemini.assignment.lab6;

import java.util.Scanner;


public class CurrentSavingsMain6_2 {
	public static void main(String[] args) throws Exception6_2 {
		Scanner sc = new Scanner(System.in);
		Person6_2 p = new Person6_2();
		p.setName("smith");
		p.setAge(5);
		CurrentAccount6_2 c = new CurrentAccount6_2(25000,p);
		Person6_2 p1 = new Person6_2("Kathy",26);
		SavingsAccount6_2 s = new SavingsAccount6_2(30000,p1);
		System.out.println(c.withdraw(2000.0));
		System.out.println("2000 got withdrawn ");
		System.out.println("Updated balance of "+c.getName()+" is : "+c.getBalance());
		System.out.println(s.withdraw(2000.0));
		System.out.println("2000 got deposited ");
		System.out.println("Updated balance of "+s.getName()+" is : "+s.getBalance());
		System.out.println(c);
		System.out.println(s);
	}
}
