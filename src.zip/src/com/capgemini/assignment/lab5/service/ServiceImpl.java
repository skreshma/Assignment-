package com.capgemini.assignment.lab5.service;

import com.capgemini.assignment.lab5.bean.Employee;

public class ServiceImpl implements Service{

	@Override
	public void findInsuranceScheme(double empSal, String empDesig, Employee emp) {
		//Employee emp = new Employee();
		System.out.println(empSal);
		if((empSal > 5000 && empSal < 20000) && (empDesig.equals("System Associate"))) {
			System.out.println("Scheme C");
			emp.setEmpIScheme("Scheme C");
		} else if((empSal >= 20000 && empSal < 40000) && (empDesig.equals("Programmer"))) {
			System.out.println("Scheme B");
			emp.setEmpIScheme("Scheme B");
		} else if(empSal >= 40000 && (empDesig.equals("Manager"))) {
			System.out.println("Scheme A");
			emp.setEmpIScheme("Scheme A");
			
		} else if(empSal < 5000 && (empDesig.equals("Clerk"))) {
			System.out.println("No Scheme");
			emp.setEmpIScheme("No Scheme");
		} else {
			System.out.println("Null");
		}	
	}

	
}
