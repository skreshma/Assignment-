package com.capgemini.assignment.lab5.service;

import com.capgemini.assignment.lab5.bean.Employee;

public interface Service {
	public abstract void findInsuranceScheme(double empSal, String empDesig, Employee emp);
}
