package com.capgemini.assignment.lab5.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.capgemini.assignment.lab5.bean.Employee;
import com.capgemini.assignment.lab5.service.Service;
import com.capgemini.assignment.lab5.service.ServiceImpl;

public class Lab5_1Main {
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee Id : ");
		int empId = sc.nextInt();
		System.out.println("Enter employee Name : ");
		String empName = sc.next();
		System.out.println("Enter employee Salary : ");
		double empSal = sc.nextDouble();
		System.out.println("Enter employee Designation : ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String empDesig = br.readLine();
		ServiceImpl s1 = new ServiceImpl();
		Employee emp = new Employee(empId,empName,empSal,empDesig);
		s1.findInsuranceScheme(empSal,empDesig,emp);
		System.out.println(emp.toString());
	}
}
