package com.capgemini.assignment.lab5.pl;

public class LabMain5_3 {
	public static void main(String[] args) {
		Person5_3 p = new Person5_3("Adyan",1);
		LabExtend5_3 le = new LabExtend5_3(25000,p);
		le.withdraw(2000);
	}
}
