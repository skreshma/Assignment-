package com.capgemini.assignment.lab5.pl;

public abstract class Lab5_3 extends Person5_3 {
	long accNum;
	double balance;
	Person5_3 accHolder;
	static long count = 1;
	public Lab5_3(double balance, Person5_3 accHolder) {
		super();
		this.accNum = count;
		count += 1;
		this.balance = balance;
		this.name = accHolder.getName();
		this.age = accHolder.getAge();
	}
	public Lab5_3(String name, float age) {
		super(name, age);
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public abstract void withdraw(double amt);
	
}
