package com.capgemini.assignment.lab5.pl;

public class Lab5_2 {

}
