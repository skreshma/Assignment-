package com.capgemini.assignment.lab5.pl;

public class Person5_3 {
	String name;
	float age;
	public Person5_3(String name, float age) {
		super();
		this.name = name;
		this.age = age;
	}
	public Person5_3() {
		super();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	
}
