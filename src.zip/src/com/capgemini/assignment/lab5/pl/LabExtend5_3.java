package com.capgemini.assignment.lab5.pl;

public class LabExtend5_3 extends Lab5_3 {

	public LabExtend5_3(double balance, Person5_3 accHolder) {
		super(balance, accHolder);
	}

	@Override
	public void withdraw(double amt) {
		System.out.println(this.name+" Balance is : "+balance);
		if(balance-amt < 500)
			System.out.println("Can't withdraw amount because minimum balance is 500");
		this.balance = balance-amt;
		System.out.println("After withdrawl balance of "+this.name+" is : "+this.balance);
		
	}
	

}
