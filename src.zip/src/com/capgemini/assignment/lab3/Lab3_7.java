package com.capgemini.assignment.lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Lab3_7 {
	String firstName;
	String lastName;
	char gender;	
	String dob;
	
	public Lab3_7() {
		super();
	}
	public Lab3_7(String firstName, String lastName, char gender, String dob) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.dob = dob;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	@Override
	public String toString() {
		return "Person Details:\n_______________\nFirst Name: " + firstName + "\nLast Name: " + lastName + "\nGender: " + gender;
	}
	public void calculateAge() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.parse(dob,formatter);
		//System.out.println(date);
		LocalDate end = LocalDate.now();
		//System.out.println(end);
		Period period = Period.between(date, end);
		//System.out.println(period.getYears());
		//return res;
	
		
	}
	public String getFullName() {
		String name = ""+firstName+" "+lastName;
		return name;
	}
}
