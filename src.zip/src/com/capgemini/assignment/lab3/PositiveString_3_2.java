package com.capgemini.assignment.lab3;

import java.util.Scanner;

public class PositiveString_3_2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string : ");
		String str = sc.next();
		int len = str.length();
		int c = 0;
		for(int i = 0;i < len-1;i++) {
			if(str.charAt(i+1) > str.charAt(i)) {
				c++;
			}
		}
		if(len-1 == c)
			System.out.println("true");
		else
			System.out.println("false");
	}
}
