package com.capgemini.assignment.lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

import com.capgemini.assignment.lab2.Person_2_3;

public class LabMain3_7 {
	public static void main(String[] args) {
		Lab3_7 l = new Lab3_7("shaik","reshma",'f',"29/01/2020");
		System.out.println(l);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.parse("29/01/2000",formatter);
		//System.out.println(date);
		LocalDate end = LocalDate.now();
		//System.out.println(end);
		Period period = Period.between(date, end);
		System.out.println("Age : "+period.getYears());
		//System.out.println(l.calculateAge());
		//System.out.println(l.getDob());
		System.out.println("Full Name : "+l.getFullName());
	}
}
