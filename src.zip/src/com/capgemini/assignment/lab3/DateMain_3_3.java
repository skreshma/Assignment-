package com.capgemini.assignment.lab3;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Scanner;

public class DateMain_3_3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter date in dd/mm/yyyy format : ");
		String s = sc.next();
		Date_3_3 d = new Date_3_3();
		d.DateDuration(s);
	}
}
