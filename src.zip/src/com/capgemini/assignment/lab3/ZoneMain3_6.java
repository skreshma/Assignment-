package com.capgemini.assignment.lab3;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZoneMain3_6 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter zone : ");
		String zone = sc.next();
		Zone3_6 z = new Zone3_6();
		ZonedDateTime currentTimeInParis = ZonedDateTime.now(ZoneId.of(zone));
		z.getcurrentZone();
	}
}
