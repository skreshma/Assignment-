package com.capgemini.assignment.lab3;

import java.util.Scanner;

public class LocalDatesMain_3_4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter date in dd/mm/yyyy format : ");
		String startDate = sc.next();
		LocalDates3_4 l = new LocalDates3_4();
		l.getLocalDates(startDate);
		
	}
}
