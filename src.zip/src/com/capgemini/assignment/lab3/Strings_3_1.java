package com.capgemini.assignment.lab3;

import java.util.Scanner;

public class Strings_3_1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String : ");
		String str = sc.next();
		boolean iterate = true;
		while(iterate) {
			System.out.println("Enter your choice\n1.Add the string to itself\n2.Replace odd positions with #\n3.Remove duplicate characters in the string\n4.Change odd characters to upper case");
			int choice = sc.nextInt();
			switch(choice) {
			case 1:
				String st = "";
				st += str+str;
				System.out.println("String : "+st);
				break;
			case 2:
				String s = "";
				for(int i = 0;i < str.length();i++) {
					if((i+1)%2 != 0) 
						s += '#';
					else
						s += str.charAt(i);
				}
				System.out.println("After replacing # in odd positions : "+s);
				break;
			case 3:
				char[] strAry = str.toCharArray();
				String dup = "";
				for(char ch : strAry) {
					if(dup.indexOf(ch) == -1)
						dup += ch;
				}
				System.out.println("After removing duplicates : "+dup);
				break;
			case 4:
				String st1 = "";
				for(int i = 0;i < str.length();i++) {
					if((i+1)%2 != 0)
						if(str.charAt(i) >= 'a' && str.charAt(i) <= 'z')
							st1 += (char)(str.charAt(i)-32);
						else
							st1 += str.charAt(i);
					else
						st1 += str.charAt(i);
				}
				System.out.println("After converting lowercase to uppercase in odd position : "+st1);
				break;
				
			}
			System.out.println("Do you want to continue y/n?");
			char y_n = sc.next().charAt(0);
			if(y_n == 'y')
				iterate = true;
			else
				iterate = false;
				
		}
		System.out.println("Thank you!!!!!!!!");
		}
		
	}

