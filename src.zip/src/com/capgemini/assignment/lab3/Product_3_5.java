package com.capgemini.assignment.lab3;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;

public class Product_3_5 {

	public void getExpireDate(String purchaseDate, int months, int years) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.parse(purchaseDate,formatter);
		int month = date.getMonthValue();
		int year = date.getYear();
		int day = date.getDayOfMonth();
		month += months;
		year += years;
		if(month > 12) {
			year = year+(month/12);
			month = (month-(12*(month/12)));
			
		}
		System.out.println(day+"/"+month+"/"+year);
	}

}
