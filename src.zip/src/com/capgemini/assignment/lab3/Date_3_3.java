package com.capgemini.assignment.lab3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.text.DateFormatter;

public class Date_3_3 {
	public void DateDuration(String text) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.parse(text,formatter);
		System.out.println(date);
	}
}
