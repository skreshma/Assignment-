package com.capgemini.assignment.lab3;

import java.time.ZonedDateTime;

public class Zone3_6 {
	ZonedDateTime currentTime = ZonedDateTime.now();

	public void getcurrentZone() {
		ZonedDateTime currentTime = ZonedDateTime.now();
		System.out.println(currentTime);
	}

	
}
