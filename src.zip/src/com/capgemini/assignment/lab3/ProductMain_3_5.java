package com.capgemini.assignment.lab3;

import java.util.Scanner;

public class ProductMain_3_5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter purchase date : ");
		String purchaseDate = sc.next();
		System.out.println("Enter warrantee period months/years : ");
		int months = sc.nextInt();
		int years = sc.nextInt();
		Product_3_5 p = new Product_3_5();
		p.getExpireDate(purchaseDate,months,years);
	}
}
