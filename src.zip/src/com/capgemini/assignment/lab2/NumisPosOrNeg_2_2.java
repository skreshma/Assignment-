package com.capgemini.assignment.lab2;

import java.util.Scanner;

public class NumisPosOrNeg_2_2 {
	public static void main(String[] args) {
		int Num = Integer.parseInt(args[0]);
		if(Num >= 0)
			System.out.println("Num is Positive");
		else
			System.out.println("Num is Negative");
	}
}
