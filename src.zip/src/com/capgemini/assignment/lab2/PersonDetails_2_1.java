package com.capgemini.assignment.lab2;

public class PersonDetails_2_1 {
	public static void main(String[] args) {
		System.out.println("Person Details:\n______________\nFirst Name: Divya\nLast Name: Bharathi\nGender: F\nAge: 20\nWeight: 85.55");
	}
}
