package com.capgemini.assignment.lab2;

import java.util.Scanner;


public class EnumMain_2_5 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Phone Number : ");
		Long phone = sc.nextLong();
		System.out.println("Enter gender :");
		char choice = sc.next().charAt(0);

		if(choice == 'M') {
			EnumePgm_2_5 ep = new EnumePgm_2_5("Anyam","Arya",Gender.M,phone);
			System.out.println(ep);
		} else {
			EnumePgm_2_5 ep = new EnumePgm_2_5("Anyam","Arya",Gender.F,phone);
			System.out.println(ep);
		}
		
		}
					
	}
	

