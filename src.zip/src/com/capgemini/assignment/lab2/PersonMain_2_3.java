package com.capgemini.assignment.lab2;

import java.util.Scanner;

public class PersonMain_2_3 {
	public static void main(String[] args) {
		Person_2_3 p1 = new Person_2_3("Anyam","Arya",'F');
		System.out.println(p1);
	}
}
