package com.capgemini.assignment.lab2;

public class Person_2_3 {
	String firstName;
	String lastName;
	char gender;
	
	public Person_2_3() {
		super();
	}
	
	

	public Person_2_3(String firstName, String lastName, char gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}



	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}


	@Override
	public String toString() {
		return "Person Details:\n_______________\nFirst Name: " + firstName + "\nLast Name: " + lastName + "\nGender: " + gender;
	}

	
	
}
