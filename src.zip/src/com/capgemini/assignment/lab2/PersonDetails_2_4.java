package com.capgemini.assignment.lab2;

import java.util.Scanner;

public class PersonDetails_2_4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Phone Number : ");
		Long phone = sc.nextLong();
		Person_2_4 p1 = new Person_2_4("Anyam","Arya",'F',phone);
		System.out.println(p1);
	}
}
