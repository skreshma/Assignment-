package com.capgemini.assignment.lab2;

public class Person_2_4 {
	String firstName;
	String lastName;
	char gender;
	Long phonenumber;
	
	public Person_2_4() {
		super();
	}

	public Person_2_4(String firstName, String lastName, char gender, Long phonenumber) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.phonenumber = phonenumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public Long getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(Long phonenumber) {
		this.phonenumber = phonenumber;
	}

	@Override
	public String toString() {
		return "Person Details:\n______________\nFirst Name: " + firstName + "\nLast Name: " + lastName + "\nGender: " + gender + "\nPhone Number: "
				+ phonenumber;
	}
	
}
