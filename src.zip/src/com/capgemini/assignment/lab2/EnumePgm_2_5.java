package com.capgemini.assignment.lab2;
enum Gender {M,F}


public class EnumePgm_2_5 {
	String firstName;
	String lastName;
	Gender gender;
	Long phonenumber;
	public EnumePgm_2_5(String firstName, String lastName, Gender gender, Long phonenumber) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.phonenumber = phonenumber;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public Long getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(Long phonenumber) {
		this.phonenumber = phonenumber;
	}
	@Override
	public String toString() {
		return "Person Details:\nfirstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender + ", phonenumber="
				+ phonenumber + "]";
	}
	
	
}
