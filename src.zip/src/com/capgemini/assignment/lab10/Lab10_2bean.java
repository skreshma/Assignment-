package com.capgemini.assignment.lab10;

public class Lab10_2bean {
	int empId;
	String empName;
	int empSalary;
	String empDesig;
	String empIScheme;
	public Lab10_2bean(int empId, String empName, int empSalary, String empDesig) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empDesig = empDesig;
		this.empIScheme = empIScheme;
	}
	public Lab10_2bean() {
		super();
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}
	public String getEmpDesig() {
		return empDesig;
	}
	public void setEmpDesig(String empDesig) {
		this.empDesig = empDesig;
	}
	public String getEmpIScheme() {
		return empIScheme;
	}
	public void setEmpIScheme(String empIScheme) {
		this.empIScheme = empIScheme;
	}
	@Override
	public String toString() {
		return "Lab10_2bean [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empDesig="
				+ empDesig + ", empIScheme=" + empIScheme + "]";
	}
	
	
}
