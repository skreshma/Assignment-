package com.capgemini.assignment.lab10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PersonProperties10_1 {
	public static void main(String[] args) throws Exception {
		Properties p = new Properties();
		FileInputStream fis = new FileInputStream("myprop.properties");
		p.load(fis);
		System.out.println(p);
		
		FileInputStream fis1 = new FileInputStream("myprop.properties");
		p.load(fis1);
		System.out.println(p.getProperty("url"));
		System.out.println(p.getProperty("username"));
		System.out.println(p.getProperty("password"));
	}
}
