package com.capgemini.assignment.lab10;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.assignment.lab7.Lab7_3_bean;

public class Lab10_2ServiceImpl {

	public void addEmployee(Lab10_2bean l) throws Exception {
		
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "Capgemini1234");
		PreparedStatement ps = con.prepareStatement("insert into example1 values(?,?,?,?,?)");
		ps.setInt(1, l.getEmpId());
		ps.setString(2, l.getEmpName());
		ps.setInt(3, l.getEmpSalary());
		ps.setString(4, l.getEmpDesig());
		String scheme = findInsuranceScheme(l.getEmpSalary(),l.getEmpDesig(),l);
		ps.setString(5, scheme);
		ps.executeUpdate();
		System.out.println("Inserted successfully");
		con.close();
	}
	
	public void deleteEmployee(Lab10_2bean l) throws SQLException {
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "Capgemini1234");
		Statement st = con.createStatement();
		int rows = st.executeUpdate("delete from example1 where empid = 1");
		System.out.println(rows+" deleted successfully");
		con.close();
	}
	
	public void getEmployeeByScheme(String scheme) throws SQLException {
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "Capgemini1234");
		PreparedStatement ps = con.prepareStatement("select * from example1 where empIScheme = ?");
		
		ps.setString(1,scheme);
		ResultSet  rs = ps.executeQuery();
		while(rs.next()) {
			int empid = rs.getInt(1);
			String name = rs.getString(2);
			int salary = rs.getInt(3);
			String desig = rs.getString(4);
			String ischeme = rs.getString("empischeme");
			System.out.println("empid = "+empid+",empname = "+name+",salary = "+salary+",desig = "+desig+",scheme = "+scheme);
		}
		con.close();
		
	}
	
	public void sortEmployee(Lab10_2bean l) throws SQLException {
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "Capgemini1234");
		PreparedStatement ps = con.prepareStatement("select * from example1 order by(empid)");
		
		//ps.setInt(1,empid);
		ResultSet  rs = ps.executeQuery();
		while(rs.next()) {
			int empid1 = rs.getInt(1);
			String name = rs.getString(2);
			int salary = rs.getInt(3);
			String desig = rs.getString(4);
			String ischeme = rs.getString(5);
			System.out.println("empid = "+empid1+",empname = "+name+",salary = "+salary+",desig = "+desig+",scheme = "+l.getEmpIScheme());
		}
		con.close();
	}
	
	String findInsuranceScheme(int empSal, String empDesig, Lab10_2bean l) {
		String scheme = "";
		System.out.println(empSal);
		if((empSal > 5000 && empSal < 20000) && (empDesig.equals("System Associate"))) {
			//System.out.println("Scheme C");
			l.setEmpIScheme("Scheme C");
			scheme = "Scheme C";
		} else if((empSal >= 20000 && empSal < 40000) && (empDesig.equals("Programmer"))) {
			//System.out.println("Scheme B");
			l.setEmpIScheme("Scheme B");
			scheme = "Scheme B";
		} else if(empSal >= 40000 && (empDesig.equals("Manager"))) {
			//System.out.println("Scheme A");
			l.setEmpIScheme("Scheme A");
			scheme = "Scheme A";
			
		} else if(empSal < 5000 && (empDesig.equals("Clerk"))) {
			System.out.println("No Scheme");
			l.setEmpIScheme("No Scheme");
		} else {
			System.out.println("Null");
		}
		return scheme;
	}

	
	
}
