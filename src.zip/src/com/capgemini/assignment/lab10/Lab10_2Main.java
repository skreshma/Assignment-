package com.capgemini.assignment.lab10;

public class Lab10_2Main {
	public static void main(String[] args) throws Exception {
		Lab10_2bean l = new Lab10_2bean(1,"Adyan",23000,"Programmer");
		Lab10_2ServiceImpl s = new Lab10_2ServiceImpl();
		//s.addEmployee(l);
		String scheme = s.findInsuranceScheme(23000,"Programmer",l);
		l.setEmpIScheme(scheme);
		//s.addEmployee(l);
		//s.deleteEmployee(l);
		//s.getEmployeeByScheme("Scheme A");
		s.sortEmployee(l);
	}
}
