package com.capgemini.assignment.lab7;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.TreeSet;

import com.capgemini.assignment.lab5.bean.Employee;

public class Lab7_3ServiceImpl implements Lab7_3Service {

	HashMap<Integer,Lab7_3_bean> hm = new HashMap();
	@Override
	public void addEmployee(Lab7_3_bean emp1) {
		hm.put(emp1.getEmpId(), emp1);
		String scheme = findInsuranceScheme(emp1.getEmpSalary(),emp1.getEmpDesig(),emp1);
		emp1.setEmpIScheme(scheme);
		System.out.println("Employee added successfully\n"+emp1);
	}

	@Override
	public boolean deleteEmployee(int empId) {
		Collection<Lab7_3_bean> al =  hm.values();
		for(Lab7_3_bean c:al) {
			int id = c.getEmpId();
			if(empId == id) {
				hm.remove(empId);
				System.out.println("Deleted Successfully\n"+hm);
				return true;
			}
		}
		return false;
	}
	
	public void sortEmployee() {
		TreeSet<Lab7_3_bean> ts = new TreeSet<>();
		Collection<Lab7_3_bean> c = hm.values();
		for(Lab7_3_bean l:c) {
			ts.add(l);
		}
		System.out.println(ts);
	}
	
	public void getEmpByScheme(String s) {
		ArrayList<Lab7_3_bean> a = new ArrayList<>();
		Collection<Lab7_3_bean> al =  hm.values();
		for(Lab7_3_bean c:al) {
			String sch = c.getEmpIScheme();
			if(sch.equals(s)) {
				a.add(c);
			}
		}
		System.out.println(a);
		
	}
	
	public String findInsuranceScheme(double empSal, String empDesig, Lab7_3_bean emp) {
		//Employee emp = new Employee();
		String scheme = "";
		System.out.println(empSal);
		if((empSal > 5000 && empSal < 20000) && (empDesig.equals("System Associate"))) {
			//System.out.println("Scheme C");
			emp.setEmpIScheme("Scheme C");
			scheme = "Scheme C";
		} else if((empSal >= 20000 && empSal < 40000) && (empDesig.equals("Programmer"))) {
			//System.out.println("Scheme B");
			emp.setEmpIScheme("Scheme B");
			scheme = "Scheme B";
		} else if(empSal >= 40000 && (empDesig.equals("Manager"))) {
			//System.out.println("Scheme A");
			emp.setEmpIScheme("Scheme A");
			scheme = "Scheme A";
			
		} else if(empSal < 5000 && (empDesig.equals("Clerk"))) {
			System.out.println("No Scheme");
			emp.setEmpIScheme("No Scheme");
		} else {
			System.out.println("Null");
		}
		return scheme;
	}
}
