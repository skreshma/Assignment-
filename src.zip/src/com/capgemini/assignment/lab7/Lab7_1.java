package com.capgemini.assignment.lab7;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Lab7_1 {
	public static void main(String[] args) {
		String a[] = {"Pen","Pencil","Mobile"};
		Arrays.sort(a);
		for(int i = 0;i < a.length;i++)
			System.out.println(a[i]);
	}
}
