package com.capgemini.assignment.lab7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.capgemini.assignment.lab5.bean.Employee;

public class Lab7_3Main {
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		/*System.out.println("Enter employee Id : ");
		int empId = sc.nextInt();
		System.out.println("Enter employee Name : ");
		String empName = sc.next();
		System.out.println("Enter employee Salary : ");
		double empSal = sc.nextDouble();
		System.out.println("Enter employee Designation : ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String empDesig = br.readLine();*/
		Lab7_3_bean emp1 = new Lab7_3_bean(1,"Adyan",20000,"Programmer");
		//Lab7_3_bean emp1 = new Lab7_3_bean(empId,empName,empSal,empDesig);
		Lab7_3_bean emp2 = new Lab7_3_bean(2,"Reshma",40000,"Manager");
		Lab7_3_bean emp3 = new Lab7_3_bean(3,"Mathin",45000,"Manager");
		Lab7_3ServiceImpl s = new Lab7_3ServiceImpl();
		s.addEmployee(emp1);
		s.addEmployee(emp2);
		s.addEmployee(emp3);
		s.getEmpByScheme("Scheme A");
		s.deleteEmployee(2);
		Lab7_3_bean emp4 = new Lab7_3_bean(4,"Anju",30000,"Programmer");
		s.addEmployee(emp4);
		s.sortEmployee();
	}
}
