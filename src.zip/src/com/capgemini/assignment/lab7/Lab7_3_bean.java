package com.capgemini.assignment.lab7;

public class Lab7_3_bean implements Comparable {
	int empId;
	String empName;
	double empSalary;
	String empDesig;
	String empIScheme;
	
	public Lab7_3_bean() {
		super();
	}

	public Lab7_3_bean(int empId, String empName, double empSalary, String empDesig) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empDesig = empDesig;
		this.empIScheme = empIScheme;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	public String getEmpDesig() {
		return empDesig;
	}

	public void setEmpDesig(String empDesig) {
		this.empDesig = empDesig;
	}

	public String getEmpIScheme() {
		return empIScheme;
	}

	public void setEmpIScheme(String empIScheme) {
		this.empIScheme = empIScheme;
	}

	@Override
	public String toString() {
		return "empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empDesig="
				+ empDesig + ", empIScheme=" + empIScheme;
	}

	@Override
	public int compareTo(Object o) {
		Lab7_3_bean l = (Lab7_3_bean) o;
		if(this.empSalary == l.getEmpSalary())
			return 0;
		else if(this.empSalary > l.getEmpSalary())
			return 1;
		else
			return -1;
	}
	
}
