package com.capgemini.assignment.lab7;

import com.capgemini.assignment.lab5.bean.Employee;

public interface Lab7_3Service {
	public abstract void addEmployee(Lab7_3_bean emp);
	public abstract boolean deleteEmployee(int empId);
}
