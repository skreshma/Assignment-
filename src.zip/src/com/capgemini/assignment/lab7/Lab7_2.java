package com.capgemini.assignment.lab7;

import java.util.ArrayList;
import java.util.Collections;

public class Lab7_2 {
	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList();
		al.add("pen");
		al.add("pencil");
		al.add("Mobile");
		Collections.sort(al);
		for (String string : al) {
			System.out.println(string);
		}
		
	}
}
