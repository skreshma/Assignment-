package com.capgemini.assignment.lab8;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class LabMain8_3 {
	public static void main(String[] args) throws Exception {
		Employee8_3 e1 = new Employee8_3("Reshma",56000);
		Employee8_3 e2 = new Employee8_3("Adyan",90000);
		FileOutputStream fos = new FileOutputStream("lab8_3.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(e1);
		oos.writeObject(e2);
		fos.close();
		FileInputStream fis = new FileInputStream("lab8_3.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Employee8_3 e;
		try {
		while((e = (Employee8_3) ois.readObject()) != null) {
			System.out.println(e);
		}
		} catch(Exception ex) {
			System.out.println(ex+"\nEOF");
		}
		fis.close();
	}
}
