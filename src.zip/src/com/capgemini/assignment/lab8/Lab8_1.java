package com.capgemini.assignment.lab8;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

public class Lab8_1 {
	public static void main(String[] args) throws Exception {
		List<Character> l = new ArrayList<>();
		FileWriter fw = new FileWriter("file1.txt");
		fw.write('r');
		fw.write('e');
		fw.write('s');
		fw.write('h');
		fw.close();
		//System.out.println("end");
		FileReader fr = new FileReader("file1.txt");
		int ch = fr.read();
		while(ch != -1) {
			l.add((char)ch);
			ch = fr.read();
		}
		fr.close();
		FileWriter fw1 = new FileWriter("file1.txt");
		//System.out.println(l);
		for(int i = l.size()-1;i >= 0;i--) {
			fw1.write(l.get(i));
		}
		fw1.close();
	}
}

