package com.capgemini.assignment.lab8;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Scanner;

public class Even8_2 {
	public static void main(String[] args) throws Exception {
		
		Scanner sc = new Scanner(new FileInputStream("numbers.txt"));
		sc.useDelimiter(",");
		 
		while (sc.hasNext()) {
			int num = sc.nextInt();
			if(num%2 == 0)
				System.out.println(num);
		 
		}
		 
		sc.close();
	}
}
