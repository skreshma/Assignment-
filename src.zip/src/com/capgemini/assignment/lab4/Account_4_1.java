package com.capgemini.assignment.lab4;

public class Account_4_1 extends Person_4_1{
	long accNum;
	double balance;
	Person_4_1 accHolder;
	static long count = 1;
	
	public Account_4_1(double balance,Person_4_1 accHolder) {
		super();
		this.accNum = count;
		count += 1;
		this.balance = balance;
		this.name = accHolder.getName();
		this.age = accHolder.getAge();
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public void deposit(double amt) {
		System.out.println(this.name+" Balance is : "+this.balance);
		this.balance = balance+amt;
		
	}
	public void withdraw(double amt) {
		System.out.println(this.name+" Balance is : "+this.balance);
		if(this.balance-amt < 500)
			System.out.println("Can't withdraw amount because minimum balance is 500");
		this.balance = balance-amt;
		
	}
	
	@Override
	public String toString() {
		return "\nAccount Details :\naccNum = " + accNum + "\nbalance = " + balance + "\nname=" + name + "\nage = " + age+"\n";
	}
	
	
}
