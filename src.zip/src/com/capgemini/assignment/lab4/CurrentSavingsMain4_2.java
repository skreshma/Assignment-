package com.capgemini.assignment.lab4;

import java.util.Scanner;

public class CurrentSavingsMain4_2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Person4_2 p = new Person4_2("smith",25);
		CurrentAccount4_2 c = new CurrentAccount4_2(25000,p);
		Person4_2 p1 = new Person4_2("Kathy",26);
		SavingsAccount4_2 s = new SavingsAccount4_2(30000,p1);
		System.out.println(c.withdraw(2000.0));
		System.out.println("2000 got withdrawn ");
		System.out.println("Updated balance of "+c.getName()+" is : "+c.getBalance());
		System.out.println(s.withdraw(2000.0));
		System.out.println("2000 got deposited ");
		System.out.println("Updated balance of "+s.getName()+" is : "+s.getBalance());
		System.out.println(c);
		System.out.println(s);
	}
}
