package com.capgemini.assignment.lab4;

public class Account4_2 extends Person4_2 {
	long accNum;
	double balance;
	Person_4_1 accHolder;
	static long count = 1;
	
	public Account4_2(String name, float age) {
		super(name, age);
	}

	public Account4_2(double balance, Person4_2 p1) {
		super();
		this.accNum = count;
		count++;
		this.balance = balance;
		this.name = p1.getName();
		this.age = p1.getAge();
	}

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void deposit(double amt) {
		System.out.println(this.name + " Balance is : " + this.balance);
		this.balance = balance + amt;

	}

	public boolean withdraw(double amt) {
		if (this.balance - amt < 500) {
			System.out.println("Can't withdraw");
			return false;
		} else {
			this.balance = this.balance-amt;
			return true;
		}
	}
	
	@Override
public String toString() {
	return "\nAccount Details :\naccNum = " + accNum + "\nbalance = " + balance + "\nname=" + name + "\nage = " + age+"\n";
}

}


