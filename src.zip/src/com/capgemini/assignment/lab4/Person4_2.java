package com.capgemini.assignment.lab4;

public class Person4_2 {
		String name;
		float age;
		public Person4_2(String name, float age) {
			super();
			this.name = name;
			this.age = age;
		}
		public Person4_2() {
			super();
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public float getAge() {
			return age;
		}
		public void setAge(float age) {
			this.age = age;
		}
		
		
		
		
}
