package com.capgemini.assignment.lab4;

import java.util.Scanner;

public class AccountPersonMain_4_1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Person_4_1 p = new Person_4_1("smith",25);
		Account_4_1 a = new Account_4_1(25000,p);
		Person_4_1 p1 = new Person_4_1("Kathy",26);
		Account_4_1 a1 = new Account_4_1(30000,p1);
		a.deposit(2000);
		System.out.println("2000 got deposited ");
		System.out.println("Updated balance of "+a.getName()+" is : "+a.getBalance());
		a1.withdraw(2000);
		System.out.println("2000 got withdrawn ");
		System.out.println("Updated balance of "+a1.getName()+" is : "+a1.getBalance());
		System.out.println(a);
		System.out.println(a1);
	}
}
