package com.capgemini.assignment.lab4;

public class SavingsAccount4_2 extends Account4_2 {
	public SavingsAccount4_2(double balance, Person4_2 p1) {
		super(balance, p1);
	}

	final double minBal = 500;
	public boolean withdraw(double amt) {
		System.out.println("Savings");
		if (this.balance - amt < 500) {
			System.out.println("Can't withdraw");
			return false;
		} else {
			this.balance = this.balance-amt;
			return true;
		}
	}
}
